-- LYCAN — Tables Turso (SQLite)
-- À exécuter dans le dashboard Turso > ton DB > Shell

CREATE TABLE IF NOT EXISTS players (
  id TEXT PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  coins INTEGER DEFAULT 150,
  gold INTEGER DEFAULT 320,
  wins INTEGER DEFAULT 0,
  games INTEGER DEFAULT 0,
  points INTEGER DEFAULT 0,
  avatar TEXT DEFAULT '🐺',
  staff_role TEXT DEFAULT 'player',
  banned INTEGER DEFAULT 0,
  last_seen TEXT,
  created_at TEXT
);

CREATE TABLE IF NOT EXISTS lobbies (
  id TEXT PRIMARY KEY,
  name TEXT,
  host TEXT,
  min_players INTEGER DEFAULT 6,
  max_players INTEGER DEFAULT 12,
  visibility TEXT DEFAULT 'public',
  mode TEXT DEFAULT 'Standard',
  code TEXT,
  status TEXT DEFAULT 'waiting',
  created_at TEXT
);

CREATE TABLE IF NOT EXISTS lobby_players (
  id TEXT PRIMARY KEY,
  lobby_id TEXT,
  username TEXT,
  ready INTEGER DEFAULT 0,
  joined_at TEXT
);

CREATE TABLE IF NOT EXISTS friendships (
  id TEXT PRIMARY KEY,
  user_a TEXT,
  user_b TEXT,
  status TEXT DEFAULT 'pending',
  created_at TEXT
);

CREATE TABLE IF NOT EXISTS reports (
  id TEXT PRIMARY KEY,
  reporter TEXT,
  reported TEXT,
  reason TEXT,
  details TEXT,
  game_name TEXT,
  status TEXT DEFAULT 'pending',
  mod_note TEXT,
  created_at TEXT,
  updated_at TEXT
);

CREATE TABLE IF NOT EXISTS sanctions (
  id TEXT PRIMARY KEY,
  target TEXT,
  type TEXT,
  reason TEXT,
  mod TEXT,
  created_at TEXT
);
